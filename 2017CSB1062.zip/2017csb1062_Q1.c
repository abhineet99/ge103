#include<stdio.h>
#include<stdlib.h>
int i;

void hexConverter(int a,int i,int* arr)
{ 


  int iLoop,j;
  if(a%16>9)
   {
    for(iLoop=10;iLoop<16;iLoop++)
     {       
     if (iLoop==a%16)
         { arr[i]=iLoop+55;
                }
         }
    }
   
  else
   {
     for(iLoop=0;iLoop<10;iLoop++)
     {       
     if(iLoop==a%16)
     {
	arr[i]=iLoop+48;

     }
    }

  }
  a=a/16;
  i++;
  if(a==0)
{
for(j=i-1;j>=0;j--)
printf("%c",arr[j]);
printf("  ");
}  

  else
  hexConverter(a,i,arr);
  
}

void main()
{       for(int i=1;i<6;i++){
		printf("Enter the size of string\n");
		int iSize,iLoop;
		scanf("%d",&iSize);
        
		char* str=(char*)malloc(iSize*sizeof(char));
	
		int* arr=(int*)malloc(3*sizeof(int));
       		printf("Enter the string");
		scanf("%s",str);

       		 for(iLoop=0;iLoop<iSize;iLoop++)
			hexConverter(*(str+iLoop),0,arr);
		printf("\n");
		free(str);
		free(arr);
		}
  
          
}
