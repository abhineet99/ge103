#include<stdio.h>
int main()
{
  int iSize1,iSize2,iLoop,jLoop,iSort;

    printf("Enter the size of array 1\n");
    scanf("%d",&iSize1);
    int Arr1[iSize1];

    printf("Enter the values to be stored in array 1\n" );
    for(iLoop=0;iLoop<iSize1;iLoop++)
    scanf("%d",&Arr1[iLoop]);

      printf("Enter the size of array 2\n");
      scanf("%d",&iSize2);
      int Arr2[iSize2];

      printf("Enter the values to be stored in array 2\n" );
      for(iLoop=0;iLoop<iSize2;iLoop++)
      scanf("%d",&Arr2[iLoop]);

      int Arr3[iSize1+iSize2];

      for(iLoop=0;iLoop<iSize1;iLoop++)
      Arr3[iLoop]=Arr1[iLoop];

    for(iLoop=iSize1;iLoop<iSize1+iSize2;iLoop++)
    Arr3[iLoop]=Arr2[iLoop-iSize1];
    for(iLoop=0; iLoop<iSize1+iSize2; iLoop++)
   {
       for(jLoop=iLoop+1; jLoop<iSize1+iSize2; jLoop++)
       {
           if(Arr3[jLoop] <Arr3[iLoop])
           {
               iSort = Arr3[iLoop];
               Arr3[iLoop] = Arr3[jLoop];
               Arr3[jLoop] = iSort;
           }
       }
   }
   printf("The sorted Array is as follows\n" );
   for(iLoop=0;iLoop<iSize1+iSize2;iLoop++)
   printf("%d  ",Arr3[iLoop] );


return 0;

}
