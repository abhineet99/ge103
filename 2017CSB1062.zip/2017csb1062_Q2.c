#include<stdio.h>
#include<stdlib.h>
int iSize;

int iLoop,iStack=0,iBrack;

void push(char *cStack, char cVal)
	{
    	iStack++;
    	*(cStack+iStack)=cVal;
	}
char pop(char *cStack,int iStack)
{
    return *(cStack+iStack);
}
int Value(char value)
{
    if(value=='+'||value=='-')
	return 1;
    else if(value=='*'||value=='/')
    	return 2;
       
}

void displayStack(int iSize,char *cPrint)
{
    int iLoop;
    for(iLoop=0;iLoop<iSize;iLoop++)
        printf("%c",*(cPrint+iLoop));
}

void expressionEvaluation(int iSize, char *cResult, char *cStack,char *cMain)
    {	
	int iLoop,iBrack=0;
	
	for(iLoop=0;iLoop<=iSize;iLoop++)
		{
		if((*(cMain+iLoop)>='A' && *(cMain+iLoop)<='Z') || (*(cMain+iLoop)>='a' && *(cMain+iLoop)<='z'))
			{
			*(cResult)=*(cMain+iLoop);
			cResult++;
			
			}
		else if(*(cMain+iLoop)=='(')		
			{
			push(cStack,*(cMain+iLoop));
			iBrack=iBrack+1;
			}
		else if(*(cMain+iLoop)==')')
			{
			while(*(cStack+iStack)!='(')
               			 {
                    		*(cResult++)=pop(cStack,iStack);
                   		 iStack--;
                		 }
                	iStack--;
			}
		else if(*(cMain+iLoop)=='+' || *(cMain+iLoop)=='-' || *(cMain+iLoop)=='*' || *(cMain+iLoop)=='/' )
       			{
            		while ( *(cStack+iStack)!='('&& Value(*(cMain+iLoop))<=Value((*(cStack+iStack))))
                		{
                    		*(cResult++) = pop(cStack,iStack);
                    		iStack--;
                		}
            		push((cStack),*(cMain+iLoop));
      			}

		}
		
	(*cResult)='\0';
	
	displayStack(iSize-2*iBrack,cResult-iSize+2*iBrack);
    }

void main()
    {
	printf("Enter the length of the expression\n");
	
	scanf("%d",&iSize);
	char* cMain;
        cMain=(char*)malloc((iSize+2)*sizeof(char));
	
	printf("Enter the expression(infix)\n");
		scanf("%s",(cMain));
	char* cResult;
	cResult= (char *)malloc((iSize+1)*sizeof(char));
        char* cStack;
	cStack=(char *)malloc((iSize+1)*sizeof(char));

        *(cStack+0)='(';
	*(cMain+iSize)=')';  //start and end the array with brackets
        *(cMain+iSize+1)='\0';


	void expressionEvaluation(int,char*,char*,char*);
	expressionEvaluation(iSize,cResult,cStack,cMain);
	        
    }
