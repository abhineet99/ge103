#include<stdio.h>
int main()
{ int iRow,iColumn,iLoop,iLoop2,iStart,iEnd,iMid;
  printf("Enter the number of rows of matrix\n" );
  scanf("%d",&iRow);

  printf("Enter the number of columns of matrix\n");
  scanf("%d",&iColumn );

  int matr[iRow][iColumn],iNum,i=0;

  printf("Enter the numbers in sorted manner\n");
  for(iLoop=0;iLoop<iRow;iLoop++)
  {
    for(iLoop2=0;iLoop2<iColumn;iLoop2++)
    scanf("%d",&matr[iLoop][iLoop2] );
  }

  int iArr[iRow*iColumn];

  for(iLoop=0;iLoop<iRow;iLoop++)
  {
    for(iLoop2=0;iLoop2<iColumn;iLoop2++)
    {iArr[i]=matr[iLoop][iLoop2];
i++;
}
  }

  printf("Enter the number whose location is to be found\n" );
scanf("%d",&iNum );
iStart = 0;
   iEnd = iRow*iColumn-1;
   iMid = (iStart + iEnd) / 2;
   while ((iStart<=iEnd) && (iArr[iMid]!=iNum))
   {
       if (iNum < iArr[iMid])
           iEnd = iMid - 1;
       else
           iStart = iMid + 1;
       iMid = (iStart + iEnd) / 2;
   }
   if (iArr[iMid] == iNum)
   {
     for(i=0;i<=iRow;i++)
     {
       if(iMid+1<=i*iColumn)
       break;
     }
     iMid=iMid-(i-1)*iColumn;
     printf("Entered Number found at  %d ,%d", i,iMid+1);
   }



   else
       printf("Entered Number not present in given matrix");



}

