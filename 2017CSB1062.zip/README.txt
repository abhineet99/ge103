Abhineet Pandey
2017CSB1062
ASSIGNMENT 2

How To Run The Programs:
On Linux Terminal
1. Go to the directory where the .c files are saved.
2. Type command gcc -o filename filename.c. ( Replace filename with the name of the file you want to run)
3. Press Enter.
4. Type ./filename and press enter.

LOGICS:
Q1:Size of string is asked from the user, then one string and one pointer are declared of that size, one for storing input and other for the result. A recursive function is called which converts the equivalent ASCII values of the characters of the string int o Hex counterpart and prints it leaving spaces between two values. This process takes place 5 times, each time the array and string memory locations are cleared before moving ahead.
The function runs on the logic that it checks the remainder of the ASCII value with 16 and enters relevant value(remainder, alphabets if greater than 10) into the result array based on that. The remainders are printed in backward fashion so that hex can be obtained.

Q2: The code runs on the following algorithm. The entered expression is read from left to right, where operands are sent to the result string and operators to stack string. Whenever the coming operator(to the stack) is of lower or equal priority(/,* have higher priority than +,-),the operator which was already present is sent to result array. Whenever the brackets are found closed, the operator inside is sent to result array.
This is done using functions. Push is used to transfer characters from input to stack, pop is used to transfer characters to result array. displayStack function is declared to display the result, while expressionEvaluation contains the code for calling of these functions at suitable time.
