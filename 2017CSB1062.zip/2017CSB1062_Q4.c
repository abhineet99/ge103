#include <stdio.h>
int main()
{
  int iSize,iTest=0,i;
   char str[99999];
   printf("Enter The String\n");
   gets(str);


   for(iSize=0;str[iSize]!='\0';iSize++)

   {

   }


   for(i=0;i<iSize/2;i++)
   {
     if(str[i]==str[iSize-1-i])
     iTest=iTest+1;
   }
   if(iTest==iSize/2)
   printf("The given string is a palindrome\n");
   else
   printf("The given string is not a palindrome\n");

   return 0;
}
