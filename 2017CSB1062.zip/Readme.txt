How To Run The Programs:
On Linux Terminal
1. Go to the directory where the .c files are saved.
2. Type command gcc -o filename filename.c. ( Replace filename with the name of the file you want to run)
3. Press Enter.
4. Type ./filename and press enter.


LOGICS:
Q1:
We take a variable whose value is equal to the smaller of the two numbers whose GCD is to be found. 
Then we run a loop decreasing value of the variable by one, and checking if the variable divides both the numbers with remainder zero,
once this condition is satisfied, the loop ends and the variable value is printed as GCD.
INPUT: Two numbers
OUTPUT:GCD
Q2:
We separately determine the binary representation of the integer and decimal parts of the given float number.
Using arrays,while caculating for decimal part. we send the value 1 or 0 to the array slots,
depending on the fact that  the double of the number in the loop is greater than 1 or not, and if it is greater ,
we subtract 1 from the value and the loop continues 6-7 times, so that a good approximation is obtained.
For integer part, we apply the same logic as done already in computer lab session by getting the binary equivalent 
by multiplying suitable power of 10 wuth the remainder we get while dividing with 2 and then summing them up.
INPUT:Number
OUTPUT:Binary Representation of that number
Q3:
After asking the user the size of the arrays, we take input for the values. Then we declare a 3rd array whose size is equal to 
the sum of the sizes of the other two arrays, and then using loops we put the values of the arrays obtained by inputs from the user
into this new array. Then we apply sorting technique where we use a 3rd variable as a medium for temporarily storing values while
eventually arranging the values in ascending order using if else and loops. Then we use a loop to print these values.
INPUT: Size of arrays, values in arrays
OUTPUT:Entered values in ascending order
Q4:
First, we ask the user to enter the characters of the string. Then , using a loop we determine the size of the string as the loop ends when
we get blank value in string. Using this size thus obtained, we start comparing characters from beginning with those from the end of the string,
and add value 1 to a variable if they are equal. In the end if this variable has a value equal to the number of comparisons made, then we have a palindrome,
we use an if condition to utilise this fact.
INPUT: The String
OUTPUT: Palindrome check
Q5:
First, we ask the user to enter the number of rows and columns required, then the required values in a sorted manner. Then,
we convert this 2D array into 1D array using loop, and ask the user about the number he wants to know about. After locating it in 1D array using 
binary search, we convert the location back into the 2D form using loop. This location conversion is based on simple math logics, we use the information 
already provided to us like the number of rows and columns in the matrix and print the desired location.
INPUT: Matrix Dimensions and values, number whose location is desired
OUTPUT: Location of the number in matrix
--------------------------------------------------------------------------------------------
Abhineet Pandey
2017CSB1062@iitrpr.ac.in
