#include<stdio.h>

int main()
{
  printf("Enter A Number\n");
  float fNum,fDecimal;
scanf("%f",&fNum);
int iNum=fNum,i;

fDecimal=fNum-iNum;
int Arr[50];

for(i=0;iNum>0;i++)
{

Arr[i]=iNum%2;

iNum=iNum/2;



}
i--;

int Dec[15],j;
for(j=0;j<15;j++)
{
  fDecimal=fDecimal*2;
  if(fDecimal>=1)
  {
    Dec[j]=1;
    fDecimal=fDecimal-1;
  }
  else
  Dec[j]=0;

}
for(;i>=0;i--)
printf("%d",Arr[i] );
printf(".");
for(j=0;j<15;j++)
printf("%d",Dec[j] );






return 0;


}

