#include<stdio.h>
int main()
{
int iNum1,iNum2,iGCD;
printf("Enter first number\n");
scanf("%d",&iNum1);
printf("Enter second number\n");
scanf("%d",&iNum2);
if(iNum1>iNum2)
{
for(iGCD=iNum2;iGCD>0;iGCD--)
{
if(iNum1%iGCD==0&&iNum2%iGCD==0)
{printf("GCD of given numbers is %d\n",iGCD);
break;}
}
}
else if(iNum1<iNum2)
{
for(iGCD=iNum1;iGCD>0;iGCD--)
{
if(iNum1%iGCD==0&&iNum2%iGCD==0)
{printf("GCD of given numbers is %d\n",iGCD);
break;}
}
}
else if(iNum1=iNum2)
printf("GCD of given numbers is %d\n",iNum1);
else("GCD can't be computed if one of the numbers is zero");

return 0;

}
